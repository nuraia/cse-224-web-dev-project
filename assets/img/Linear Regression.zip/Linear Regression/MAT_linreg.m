﻿clc;
clear all;
close all;
x = [1; 2; 3; 4; 5; 6; 7];
y = [0.5; 2.5; 2; 4; 3.5; 6; 5.5];
N= length(x);

A= [N, sum(x); sum(x), sum(x.*x)];
b= [sum(y); sum(x.*y)];

phi= inv(A)*b

plot(x,y,'o');
hold on;
ym= phi(1)+phi(2).*x
plot(x,ym);

